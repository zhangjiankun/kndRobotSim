
1.运行根目录下，执行./kndrosim
2.新建工程,菜单project/new
3.加载res目录下.xml模型文件.菜单robot/load
